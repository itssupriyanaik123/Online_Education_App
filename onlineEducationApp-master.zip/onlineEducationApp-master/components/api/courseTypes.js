const courseTypes = [
    {
id:1,
color:'#055e91',
name:'Language Learning',
},
    {
id:2,
color:'#de524c',
name:'Social Sciences'
},
    {
id:3,
color:'#e7a549',
name:'Physical Science & Engineering'
},
    {
id:4,
color:'#24a8af',
name:'Personal Development'
},
    {
id:5,
color:'#0042e4',
name:'Math & Logic'
},
    {
id:6,
color:'#5652e4',
name:'Health'
},
    {
id:7,
color:'#1c2033',
name:'Information Technology'
},
    {
id:8,
color:'#a042e4',
name:'Business'
},
    {
id:9,
color:'#0092e4',
name:'Art & Humanities'
},
    {
id:10,
color:'#24a8af',
name:'Data Science'
},
]

export default courseTypes